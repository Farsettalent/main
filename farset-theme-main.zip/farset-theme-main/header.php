
<header>
  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-farset-full-light.png" alt="Farset Talent" />
</header>
