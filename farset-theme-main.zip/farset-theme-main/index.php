<?php get_header(); ?>
<main>
    <div class="container">
        <h2>Welcome to Farset Talent</h2>
        <p>This is your custom WordPress theme.</p>
    </div>
</main>
<?php get_footer(); ?>
