
<div class="hero" style="background-image:url('<?php echo get_template_directory_uri(); ?>/assets/img/hero-home.jpg');">
  <h1>Smart Hires. Stronger Teams.</h1>
</div>
