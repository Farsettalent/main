<?php
function farsettalent_enqueue_assets() {
    wp_enqueue_style('farsettalent-style', get_stylesheet_uri(), [], '1.1');
}
add_action('wp_enqueue_scripts', 'farsettalent_enqueue_assets');
?>