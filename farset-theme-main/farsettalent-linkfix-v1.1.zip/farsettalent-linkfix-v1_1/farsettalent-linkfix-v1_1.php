<?php
/**
 * Plugin Name: FarsetTalent LinkFix & Setup (v1.1)
 * Description: One-click cleanup + setup for Farset Talent. Creates/assigns pages, sets front page & menus, disables device cache, flushes permalinks, and SWITCHES THEME to Farset Talent v1.5 if installed.
 * Version: 1.1.0
 * Author: Farset Talent
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FarsetTalent_LinkFix_ThemeSwitch {
  const SLUG = 'farsettalent-linkfix-v1_1';

  public function __construct() {
    add_action('admin_menu', [$this, 'menu']);
  }

  public function menu() {
    add_management_page('Farset LinkFix v1.1', 'Farset LinkFix v1.1', 'manage_options', self::SLUG, [$this,'page']);
  }

  private function ensure_page( $title, $slug ) {
    $page = get_page_by_path( $slug );
    if ( $page ) return $page->ID;
    $id = wp_insert_post([
      'post_title'   => $title,
      'post_name'    => $slug,
      'post_status'  => 'publish',
      'post_type'    => 'page'
    ]);
    return $id;
  }

  private function trash_demo_pages() {
    $demo_titles = [
      'Make a Great Website with <span>Specia</span>',
      'Elementor #59',
      'Elementor #72',
      'Easy Customizable',
      'Plugin Supports',
      'Responsive Design',
      'Special well suited for any types of websites',
      'Process Improved',
      'Resources',
      'Hiring Outlook',
      'Trusted Services',
      'News',
      'About Us'
    ];
    foreach ( $demo_titles as $t ) {
      $page = get_page_by_title( $t );
      if ( $page && $page->post_status !== 'trash' ) {
        wp_trash_post( $page->ID );
      }
    }
  }

  private function setup_menu_primary( $pages ) {
    $menu = wp_get_nav_menu_object('Primary');
    if ( ! $menu ) {
      $menu_id = wp_create_nav_menu('Primary');
    } else {
      $menu_id = $menu->term_id;
    }
    // Remove all existing items
    $items = wp_get_nav_menu_items($menu_id);
    if ($items) {
      foreach($items as $item){
        wp_delete_post($item->ID, true);
      }
    }
    // Add items in order
    foreach ( $pages as $title => $id ) {
      wp_update_nav_menu_item( $menu_id, 0, [
        'menu-item-title'  => $title,
        'menu-item-object' => 'page',
        'menu-item-object-id' => $id,
        'menu-item-type'   => 'post_type',
        'menu-item-status' => 'publish'
      ]);
    }
    // Assign as primary location if theme supports it
    $locations = get_theme_mod('nav_menu_locations');
    if ( ! is_array($locations) ) $locations = [];
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
  }

  private function disable_litespeed_mobile_flags() {
    $opts = get_option('litespeed-cache');
    if ( is_array($opts) ) {
      $opts['guest'] = 0;
      $opts['guestonly'] = 0;
      $opts['mobile_vary'] = 0; // device-based cache
      update_option('litespeed-cache', $opts);
    }
    // Try to purge if API available
    if ( class_exists('LiteSpeed_Cache_API') ) {
      try { \LiteSpeed_Cache_API::purge_all(); } catch ( \Throwable $e ) {}
    } else {
      do_action('litespeed_purge_all');
    }
  }

  private function switch_theme_if_available() {
    // Look for a theme named "Farset Talent" with Version >= 1.5
    if ( ! function_exists('wp_get_themes') ) return [ 'switched' => false, 'reason' => 'wp_get_themes missing' ];
    $themes = wp_get_themes();
    $target_stylesheet = null;
    foreach ( $themes as $stylesheet => $theme ) {
      $name = $theme->get('Name');
      $ver  = $theme->get('Version');
      if ( strtolower(trim($name)) === 'farset talent' ) {
        // If version is numeric, try to compare
        $ok = true;
        if ( $ver ) {
          $ok = version_compare( preg_replace('/[^0-9\.]/','',$ver), '1.5', '>=' );
        }
        if ( $ok ) {
          $target_stylesheet = $stylesheet;
          break;
        }
      }
    }
    if ( $target_stylesheet && function_exists('switch_theme') ) {
      switch_theme( $target_stylesheet );
      return [ 'switched' => true, 'stylesheet' => $target_stylesheet, 'version' => $themes[$target_stylesheet]->get('Version') ];
    }
    return [ 'switched' => false, 'reason' => 'Farset Talent v1.5+ not found' ];
  }

  public function run() {
    // Ensure core pages
    $home_id    = $this->ensure_page('Home', 'home');
    $jobs_id    = $this->ensure_page('Jobs', 'jobs');
    $submit_id  = $this->ensure_page('Submit CV', 'submit-cv');
    $clients_id = $this->ensure_page('Clients', 'clients');
    $about_id   = $this->ensure_page('About', 'about');
    $contact_id = $this->ensure_page('Contact', 'contact');
    $terms_id   = $this->ensure_page('Terms of Business', 'terms-of-business');
    $privacy_id = $this->ensure_page('Privacy Policy', 'privacy-policy');

    // Set front page
    update_option('show_on_front', 'page');
    update_option('page_on_front', $home_id);

    // Build primary menu
    $this->setup_menu_primary([
      'Home' => $home_id,
      'Jobs' => $jobs_id,
      'Submit CV' => $submit_id,
      'Clients' => $clients_id,
      'About' => $about_id,
      'Contact' => $contact_id
    ]);

    // Trash demo pages
    $this->trash_demo_pages();

    // Disable device-based caching flags in LiteSpeed (if installed) and purge
    $this->disable_litespeed_mobile_flags();

    // Switch to Farset Talent v1.5 if present
    $themeSwitch = $this->switch_theme_if_available();

    // Flush permalinks
    flush_rewrite_rules();

    return [
      'pages' => [
        'home' => $home_id,
        'jobs' => $jobs_id,
        'submit' => $submit_id,
        'clients' => $clients_id,
        'about' => $about_id,
        'contact' => $contact_id,
        'terms' => $terms_id,
        'privacy' => $privacy_id
      ],
      'theme' => $themeSwitch
    ];
  }

  public function page() {
    if ( ! current_user_can('manage_options') ) return;
    echo '<div class="wrap"><h1>Farset LinkFix & Setup (v1.1)</h1>';
    if ( isset($_POST['farset_run']) && check_admin_referer('farset_run_nonce') ) {
      $result = $this->run();
      echo '<div class="notice notice-success"><p>Setup complete. Core pages ensured, Primary menu assigned, caching flags set, and theme switched (if available).</p></div>';
      echo '<pre>'. esc_html( print_r($result, true) ) .'</pre>';
    }
    echo '<form method="post">';
    wp_nonce_field('farset_run_nonce');
    submit_button('Run Fixes Now', 'primary', 'farset_run');
    echo '</form></div>';
  }
}

new FarsetTalent_LinkFix_ThemeSwitch();
