<?php
/**
 * Plugin Name: FarsetTalent LinkFix & Setup
 * Description: One-click cleanup + setup for Farset Talent theme (v1.5). Creates/assigns pages, sets front page & menus, clears LiteSpeed mobile cache flags, and removes demo/Elementor pages.
 * Version: 1.0.0
 * Author: Farset Talent
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FarsetTalent_LinkFix {
  const SLUG = 'farsettalent-linkfix';

  public function __construct() {
    add_action('admin_menu', [$this, 'menu']);
  }

  public function menu() {
    add_management_page('Farset LinkFix', 'Farset LinkFix', 'manage_options', self::SLUG, [$this,'page']);
  }

  private function ensure_page( $title, $slug ) {
    $page = get_page_by_path( $slug );
    if ( $page ) return $page->ID;
    $id = wp_insert_post([
      'post_title'   => $title,
      'post_name'    => $slug,
      'post_status'  => 'publish',
      'post_type'    => 'page'
    ]);
    return $id;
  }

  private function trash_demo_pages() {
    $demo_titles = [
      'Make a Great Website with <span>Specia</span>',
      'Elementor #59',
      'Elementor #72',
      'Easy Customizable',
      'Plugin Supports',
      'Responsive Design',
      'Special well suited for any types of websites',
      'Process Improved',
      'Resources',
      'Hiring Outlook',
      'Trusted Services',
      'News',
      'About Us'
    ];
    foreach ( $demo_titles as $t ) {
      $page = get_page_by_title( $t );
      if ( $page && $page->post_status !== 'trash' ) {
        wp_trash_post( $page->ID );
      }
    }
  }

  private function setup_menu_primary( $pages ) {
    $menu = wp_get_nav_menu_object('Primary');
    if ( ! $menu ) {
      $menu_id = wp_create_nav_menu('Primary');
    } else {
      $menu_id = $menu->term_id;
    }
    // Remove all existing items
    $items = wp_get_nav_menu_items($menu_id);
    if ($items) {
      foreach($items as $item){
        wp_delete_post($item->ID, true);
      }
    }
    // Add items in order
    foreach ( $pages as $title => $id ) {
      wp_update_nav_menu_item( $menu_id, 0, [
        'menu-item-title'  => $title,
        'menu-item-object' => 'page',
        'menu-item-object-id' => $id,
        'menu-item-type'   => 'post_type',
        'menu-item-status' => 'publish'
      ]);
    }
    // Assign as primary location if theme supports it
    $locations = get_theme_mod('nav_menu_locations');
    if ( ! is_array($locations) ) $locations = [];
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
  }

  private function disable_litespeed_mobile_flags() {
    // Turn off Guest Mode / Guest Optimization / Mobile Cache if options exist
    $opts = get_option('litespeed-cache');
    if ( is_array($opts) ) {
      $opts['guest'] = 0;
      $opts['guestonly'] = 0;
      $opts['mobile_vary'] = 0; // device-based cache
      update_option('litespeed-cache', $opts);
    }
  }

  public function run() {
    // Ensure core pages
    $home_id    = $this->ensure_page('Home', 'home');
    $jobs_id    = $this->ensure_page('Jobs', 'jobs');
    $submit_id  = $this->ensure_page('Submit CV', 'submit-cv');
    $clients_id = $this->ensure_page('Clients', 'clients');
    $about_id   = $this->ensure_page('About', 'about');
    $contact_id = $this->ensure_page('Contact', 'contact');
    $terms_id   = $this->ensure_page('Terms of Business', 'terms-of-business');
    $privacy_id = $this->ensure_page('Privacy Policy', 'privacy-policy');

    // Set front page
    update_option('show_on_front', 'page');
    update_option('page_on_front', $home_id);

    // Build primary menu
    $this->setup_menu_primary([
      'Home' => $home_id,
      'Jobs' => $jobs_id,
      'Submit CV' => $submit_id,
      'Clients' => $clients_id,
      'About' => $about_id,
      'Contact' => $contact_id
    ]);

    // Trash demo pages
    $this->trash_demo_pages();

    // Disable device-based caching flags in LiteSpeed (if installed)
    $this->disable_litespeed_mobile_flags();

    // Flush permalinks
    flush_rewrite_rules();

    return [
      'home' => $home_id,
      'jobs' => $jobs_id,
      'submit' => $submit_id,
      'clients' => $clients_id,
      'about' => $about_id,
      'contact' => $contact_id,
      'terms' => $terms_id,
      'privacy' => $privacy_id
    ];
  }

  public function page() {
    if ( ! current_user_can('manage_options') ) return;
    echo '<div class="wrap"><h1>Farset LinkFix & Setup</h1>';
    if ( isset($_POST['farset_run']) && check_admin_referer('farset_run_nonce') ) {
      $result = $this->run();
      echo '<div class="notice notice-success"><p>Setup complete. Core pages ensured and Primary menu assigned.</p></div>';
      echo '<pre>'. esc_html( print_r($result, true) ) .'</pre>';
    }
    echo '<form method="post">';
    wp_nonce_field('farset_run_nonce');
    submit_button('Run Fixes Now', 'primary', 'farset_run');
    echo '</form></div>';
  }
}

new FarsetTalent_LinkFix();
