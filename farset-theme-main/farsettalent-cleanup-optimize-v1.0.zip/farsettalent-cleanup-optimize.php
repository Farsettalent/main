<?php
/*
Plugin Name: Farset Cleanup & Optimize
Description: One-click: keep only core pages, fix navigation, set permalinks, minor performance tweaks, and purge caches.
Version: 1.0
Author: Farset Talent
*/

if (!defined('ABSPATH')) exit;

class FT_Cleanup_Optimize {
    private $slug = 'ft_cleanup_optimize';
    private $keep_pages = array('Home','Jobs','Submit CV','Clients','About','Contact','Privacy Policy','Terms of Business');

    public function __construct(){
        add_action('admin_menu', array($this,'menu'));
        add_action('admin_post_ft_run_cleanup', array($this,'run'));
    }

    public function menu(){
        add_management_page('Farset Cleanup & Optimize','Farset Cleanup','manage_options',$this->slug,array($this,'screen'));
    }

    public function screen(){
        if(!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>Farset Cleanup & Optimize</h1>';
        echo '<p>This will trash non-core pages, repair navigation, set clean permalinks, apply small performance tweaks, and purge cache.</p>';
        echo '<form method="post" action="'.admin_url('admin-post.php').'">';
        wp_nonce_field('ft_cleanup_run','ft_nonce');
        echo '<input type="hidden" name="action" value="ft_run_cleanup"/>';
        echo '<p><button class="button button-primary button-hero">Run Cleanup Now</button></p>';
        echo '</form></div>';
    }

    private function ensure_navigation(){
        // Create/ensure a Navigation post from current primary menu if exists
        $nav_title = 'Primary Navigation';
        $nav = get_page_by_title($nav_title, OBJECT, 'wp_navigation');
        if(!$nav){
            $nav_id = wp_insert_post(array(
                'post_title'=>$nav_title,
                'post_type'=>'wp_navigation',
                'post_status'=>'publish'
            ));
            $nav = get_post($nav_id);
        }
        // Build links we expect
        $links = array(
            array('Home','/'),
            array('Jobs','/jobs/'),
            array('Submit CV','/submit-cv/'),
            array('Clients','/clients/'),
            array('About','/about/'),
            array('Contact','/contact/')
        );
        $blocks = array();
        foreach($links as $l){
            $blocks[] = array(
                'blockName' => 'core/navigation-link',
                'attrs' => array('label'=>$l[0],'url'=>$l[1])
            );
        }
        $nav_blocks = array(
            'blockName'=>'core/navigation',
            'attrs'=> array(),
            'innerBlocks'=> $blocks,
            'innerHTML'=> '',
            'innerContent'=> array()
        );
        $content = serialize_blocks( array_block_editor_to_wp_blocks( array($nav_blocks) ) );
        // Fallback: use Gutenberg function to generate content
        if(empty($content)){
            $content = '<!-- wp:navigation --><ul class="wp-block-navigation__container">';
            foreach($links as $l){
                $content .= '<li class="wp-block-navigation-item"><a href="'.$l[1].'">'.$l[0].'</a></li>';
            }
            $content .= '</ul><!-- /wp:navigation -->';
        }
        wp_update_post(array('ID'=>$nav->ID, 'post_content'=>$content));
        // Update header template-part to reference this entity
        $parts = get_posts(array('post_type'=>'wp_template_part','posts_per_page'=>-1,'post_status'=>'publish'));
        foreach($parts as $p){
            if(false !== stripos($p->post_title,'header')){
                $c = $p->post_content;
                // Replace any page-list navigation with entity reference
                if(strpos($c,'wp:navigation')!==false){
                    // Inject ref attribute
                    $c = preg_replace('/(wp:navigation)([^>]*)-->/', 'wp:navigation {"ref":'.$nav->ID.'} -->', $c, 1);
                    wp_update_post(array('ID'=>$p->ID,'post_content'=>$c));
                }
            }
        }
        return $nav->ID;
    }

    public function run(){
        if(!current_user_can('manage_options') || !check_admin_referer('ft_cleanup_run','ft_nonce')) wp_die('Nope');
        $report = array();

        // 1) Trash pages not in keep list
        $all = get_posts(array('post_type'=>'page','numberposts'=>-1,'post_status'=>array('publish','draft','private')));
        foreach($all as $pg){
            if(!in_array($pg->post_title, $this->keep_pages)){
                wp_trash_post($pg->ID);
                $report[] = "Trashed page: {$pg->post_title}";
            }
        }

        // 2) Ensure core pages exist
        $slugs = array(
            'home'=>'/',
            'jobs'=>'jobs',
            'submit-cv'=>'submit-cv',
            'clients'=>'clients',
            'about'=>'about',
            'contact'=>'contact',
            'privacy-policy'=>'privacy-policy',
            'terms-of-business'=>'terms-of-business'
        );
        $ids = array();
        foreach($slugs as $title=>$slug){
            $title_clean = ucwords(str_replace('-', ' ', $title));
            if($title==='home') $title_clean = 'Home';
            $page = get_page_by_path($slug);
            if(!$page){
                $page = get_page_by_title($title_clean);
            }
            if(!$page){
                $page_id = wp_insert_post(array(
                    'post_title'=>$title_clean,
                    'post_type'=>'page',
                    'post_status'=>'publish',
                    'post_name'=>sanitize_title($slug)
                ));
                $report[] = "Created page: {$title_clean}";
                $ids[$title] = $page_id;
            } else {
                $ids[$title] = $page->ID;
            }
        }

        // 3) Set Home as static front page
        if(!empty($ids['home'])){
            update_option('show_on_front','page');
            update_option('page_on_front', $ids['home']);
        }

        // 4) Permalinks
        global $wp_rewrite;
        update_option('permalink_structure','/%postname%/');
        $wp_rewrite->set_permalink_structure('/%postname%/');
        flush_rewrite_rules();

        // 5) Disable comments on pages
        update_option('default_comment_status','closed');

        // 6) Minor performance tweaks (disable emojis & embeds)
        add_filter('emoji_svg_url', '__return_false');
        update_option('use_smilies', 0);
        // The following are runtime hooks, but store a flag so on next load a must-use file can apply them.
        update_option('ft_perf_flag', 1);

        // 7) Navigation binding
        $nav_id = $this->ensure_navigation();
        $report[] = "Navigation bound to entity ID: ".$nav_id;

        // 8) Purge LSCache if present
        if (class_exists('LiteSpeed_Cache_API')) {
            \LiteSpeed_Cache_API::purge_all();
            $report[] = "LiteSpeed purge_all triggered.";
        }

        // 9) Done → redirect with report
        set_transient('ft_cleanup_report', $report, 60);
        wp_redirect(admin_url('tools.php?page='.$this->slug.'&ft_done=1'));
        exit;
    }
}

new FT_Cleanup_Optimize();

// MU performance file creator (on next load)
if (is_admin() && get_option('ft_perf_flag')) {
    $mu_dir = WPMU_PLUGIN_DIR;
    if (!is_dir($mu_dir)) @mkdir($mu_dir);
    $mu_file = trailingslashit($mu_dir) . 'ft-no-emoji-embed.php';
    if (!file_exists($mu_file)) {
        $code = "<?php
        add_action('init', function(){
            remove_action('wp_head','print_emoji_detection_script',7);
            remove_action('admin_print_scripts','print_emoji_detection_script');
            remove_action('wp_print_styles','print_emoji_styles');
            remove_action('admin_print_styles','print_emoji_styles');
            remove_action('wp_head','wp_oembed_add_discovery_links');
            remove_action('wp_head','wp_oembed_add_host_js');
            remove_filter('the_content','do_shortcode'); // no-op
        });
        ";
        @file_put_contents($mu_file, $code);
    }
    delete_option('ft_perf_flag');
}

function ft_cleanup_admin_notices(){
    if(isset($_GET['page']) && $_GET['page']==='ft_cleanup_optimize' && isset($_GET['ft_done'])){
        $report = get_transient('ft_cleanup_report');
        if($report){
            echo '<div class="notice notice-success"><p><strong>Farset Cleanup complete:</strong></p><ul>';
            foreach($report as $line){ echo '<li>'.esc_html($line).'</li>'; }
            echo '</ul></div>';
            delete_transient('ft_cleanup_report');
        }
    }
}
add_action('admin_notices','ft_cleanup_admin_notices');
