
<?php
/**
 * Plugin Name: Farset NavClean
 * Description: Creates a clean Primary Navigation (Home, Jobs, Submit CV, Clients, About, Contact) and binds it to the Header template-part across the block theme. Also removes sample pages from the nav.
 * Version: 1.1.0
 * Author: Farset Talent
 */

if (!defined('ABSPATH')) { exit; }

class Farset_NavClean {
  public function __construct() {
    add_action('admin_menu', [$this, 'menu']);
    add_action('admin_post_farset_navclean_run', [$this, 'run']);
  }

  public function menu() {
    add_management_page('Farset NavClean', 'Farset NavClean', 'manage_options', 'farset-navclean', [$this, 'page']);
  }

  public function page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap">
      <h1>Farset NavClean</h1>
      <p>This will create a Navigation entity named <strong>Primary Navigation</strong> with links to: Home, Jobs, Submit CV, Clients, About, Contact, and bind it to the Header template-part of your active block theme.</p>
      <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <?php wp_nonce_field('farset_navclean_nonce'); ?>
        <input type="hidden" name="action" value="farset_navclean_run"/>
        <p><button class="button button-primary">Run Nav Clean</button></p>
      </form>
    </div>
    <?php
  }

  private function create_nav_entity() {
    $title = 'Primary Navigation';
    $existing = get_page_by_title($title, OBJECT, 'wp_navigation');
    if ($existing) return $existing->ID;

    // Build block markup list of nav links
    $links = [
      ['Home', home_url('/')],
      ['Jobs', home_url('/jobs/')],
      ['Submit CV', home_url('/submit-cv/')],
      ['Clients', home_url('/clients/')],
      ['About', home_url('/about/')],
      ['Contact', home_url('/contact/')],
    ];
    $inner = '';
    foreach ($links as $l) {
      $inner .= '<!-- wp:navigation-link {"label":"' . esc_js($l[0]) . '","url":"' . esc_url_raw($l[1]) . '","kind":"custom"} /-->';
    }
    $content = '<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","justifyContent":"right"},"style":{"spacing":{"blockGap":"20px"}}} -->' . $inner . '<!-- /wp:navigation -->';

    $id = wp_insert_post([
      'post_type' => 'wp_navigation',
      'post_title' => $title,
      'post_status' => 'publish',
      'post_content' => $content,
    ]);
    return $id;
  }

  private function bind_header_to_nav($nav_id) {
    global $wpdb;
    // Find all header template-parts
    $headers = $wpdb->get_results( $wpdb->prepare(
      "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_type='wp_template_part' AND post_status IN ('publish','draft','auto-draft') AND post_title LIKE %s",
      $wpdb->esc_like('header') . '%'
    ) );
    if (!$headers) return 0;

    $updated = 0;
    foreach ($headers as $h) {
      $blocks = parse_blocks($h->post_content);
      $changed = false;
      array_walk($blocks, function(&$block) use (&$changed, $nav_id){
        if ($block['blockName'] === 'core/navigation') {
          $block['attrs']['ref'] = intval($nav_id);
          // clean page-list fallback
          unset($block['innerBlocks']);
          $changed = true;
        }
      });
      if ($changed) {
        $new_content = serialize_blocks($blocks);
        wp_update_post([ 'ID' => $h->ID, 'post_content' => $new_content ]);
        $updated++;
      }
    }
    return $updated;
  }

  public function run() {
    if (!current_user_can('manage_options') || !check_admin_referer('farset_navclean_nonce')) {
      wp_die('Not allowed.');
    }
    $nav_id = $this->create_nav_entity();
    $updated = $this->bind_header_to_nav($nav_id);

    // Flush caches/permalinks lightly
    flush_rewrite_rules(false);

    wp_safe_redirect( add_query_arg([
      'page' => 'farset-navclean',
      'nav_id' => $nav_id,
      'updated_headers' => $updated,
      'done' => 1
    ], admin_url('tools.php')) );
    exit;
  }
}

new Farset_NavClean();
?>
