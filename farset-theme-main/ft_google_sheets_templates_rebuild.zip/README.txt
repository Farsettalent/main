Farset Talent — Google Workspace Data Layer (Templates)
Generated: 2025-08-25T15:06:47.124327Z

Files:
- candidates.csv: Candidate system-of-record (light ATS)
- clients.csv: Client CRM
- jobs.csv: Job tracker (links to site slugs and Apply URLs)
- invoices.csv: Invoice log

Suggested Drive Structure:
/Farset Talent
  /Candidates
    /{LastName}_{FirstName}_{YYYYMMDD}/
      /CV/
      /ParserJSON/
      /Comms/
  /Clients/
    /{ClientName}/
      /Contracts/
      /Intake/
  /Jobs/
  /Invoices/{YYYY}/

GitHub Actions Deploy (SFTP to EasyWP):
- Add repo secrets: SFTP_HOST, SFTP_USER, SFTP_PASS, SFTP_PORT=22, SFTP_TARGET_DIR

Make.com Scenarios (Google-first):
- onCVUpload: WPForms -> Drive (CV) -> Sheets (candidates) -> Twilio ack
- createOrMergeCandidate: dedupe on email+phone -> update tags
- clientEnquiryIntake: site form -> Sheets (clients) -> task
- invoiceAutomation: placement -> Google Docs invoice -> PDF in Drive
