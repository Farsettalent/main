<?php
/**
 * Plugin Name: FarsetTalent HardFix (v1.0)
 * Description: One-click full repair for Block Theme rendering: disable CDN/LiteSpeed, force no-cache MU plugin, switch to Farset Talent v1.6, rebuild pages & Primary Navigation (wp_navigation), bind header to it, set front page and permalinks, flush & verify.
 * Version: 1.0.0
 * Author: Farset Talent
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FarsetTalent_HardFix {
  const SLUG = 'farsettalent-hardfix-v1.0';
  const MU_FILE = 'farsettalent-nocache.php';

  public function __construct() {
    add_action('admin_menu', [$this, 'menu']);
  }

  public function menu() {
    add_management_page('Farset HardFix', 'Farset HardFix', 'manage_options', self::SLUG, [$this, 'page']);
  }

  private function create_mu_nocache() {
    $dir = WP_CONTENT_DIR . '/mu-plugins';
    if ( ! file_exists( $dir ) ) mkdir( $dir, 0755, true );
    $file = $dir . '/' . self::MU_FILE;
    $code = <<<'PHP'
<?php
/*
Plugin Name: Farset NoCache MU
Description: Forces no-cache headers while repairing site; safe to delete after fixes.
*/
if ( ! defined('ABSPATH') ) exit;
define('DONOTCACHEPAGE', true);
define('DONOTCACHEOBJECT', true);
define('DONOTCACHEDB', true);
add_action('send_headers', function(){
  if ( function_exists('nocache_headers') ) { nocache_headers(); }
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  header('Pragma: no-cache');
  header('Expires: 0');
});
PHP;
    file_put_contents($file, $code);
    return $file;
  }

  private function remove_mu_nocache() {
    $file = WP_CONTENT_DIR . '/mu-plugins/' . self::MU_FILE;
    if ( file_exists( $file ) ) unlink( $file );
    return ! file_exists( $file );
  }

  private function deactivate_litespeed() {
    if ( function_exists('deactivate_plugins') ) {
      @deactivate_plugins( 'litespeed-cache/litespeed-cache.php', true );
    }
    // Also flip common LS options off if remain in db
    update_option('litespeed.conf.cache', 0);
    update_option('litespeed.conf.cache_browser', 0);
    update_option('litespeed.conf.guest', 0);
    update_option('litespeed.conf.cdn', 0);
    return true;
  }

  private function ensure_theme() {
    // Prefer Farset Talent version >= 1.6 if installed
    $themes = wp_get_themes();
    $target_stylesheet = '';
    foreach ( $themes as $stylesheet => $theme ) {
      if ( strtolower($theme->get('Name')) === 'farset talent' ) {
        $ver = $theme->get('Version');
        if ( version_compare($ver, '1.6', '>=') ) {
          $target_stylesheet = $stylesheet;
          break;
        } else {
          $target_stylesheet = $stylesheet; // at least switch to it
        }
      }
    }
    if ( $target_stylesheet ) {
      switch_theme( $target_stylesheet );
      return $target_stylesheet;
    }
    return 'not-found';
  }

  private function ensure_page( $title, $slug, $content = '' ) {
    $existing = get_page_by_path( $slug );
    $page_id = $existing ? $existing->ID : wp_insert_post([
      'post_title'   => $title,
      'post_name'    => $slug,
      'post_status'  => 'publish',
      'post_type'    => 'page'
    ]);
    if ( $content ) {
      wp_update_post([ 'ID' => $page_id, 'post_content' => $content ]);
    }
    return $page_id;
  }

  private function rebuild_pages() {
    $home = $this->ensure_page('Home', 'home', '<!-- wp:heading {"textAlign":"center","level":1} --><h1 class="has-text-align-center">Smart Hires. Stronger Teams.</h1><!-- /wp:heading -->');
    $jobs = $this->ensure_page('Jobs', 'jobs', '<!-- wp:heading --><h2>Jobs</h2><!-- /wp:heading -->');
    $submit = $this->ensure_page('Submit CV', 'submit-cv', '<!-- wp:paragraph --><p>Email <a href="mailto:info@farsettalent.com">info@farsettalent.com</a> or use WhatsApp.</p><!-- /wp:paragraph -->');
    $clients = $this->ensure_page('Clients', 'clients', '<!-- wp:heading --><h2>Clients</h2><!-- /wp:heading -->');
    $about = $this->ensure_page('About', 'about', '<!-- wp:heading --><h2>About</h2><!-- /wp:heading -->');
    $contact = $this->ensure_page('Contact', 'contact', '<!-- wp:paragraph --><p>Email: <a href="mailto:info@farsettalent.com">info@farsettalent.com</a></p><!-- /wp:paragraph -->');

    update_option('show_on_front', 'page');
    update_option('page_on_front', $home);

    return compact('home','jobs','submit','clients','about','contact');
  }

  private function setup_menus_and_navigation( $pages ) {
    // Build classic nav "Primary"
    $menu = wp_get_nav_menu_object('Primary');
    if ( ! $menu ) $menu_id = wp_create_nav_menu('Primary'); else $menu_id = $menu->term_id;
    // Clear items
    $items = wp_get_nav_menu_items($menu_id);
    if ($items) foreach($items as $i) wp_delete_post($i->ID, true);

    $order = ['Home'=>'home','Jobs'=>'jobs','Submit CV'=>'submit','Clients'=>'clients','About'=>'about','Contact'=>'contact'];
    foreach ( $order as $title => $key ) {
      $id = $pages[strtolower(str_replace(' ','',$title))] ?? $pages[$key] ?? 0;
      if ( $id ) {
        wp_update_nav_menu_item($menu_id, 0, [
          'menu-item-title' => $title,
          'menu-item-object' => 'page',
          'menu-item-object-id' => $id,
          'menu-item-type' => 'post_type',
          'menu-item-status' => 'publish'
        ]);
      }
    }
    // Create wp_navigation entity from menu items
    $nav_post = get_page_by_title('Primary Navigation', OBJECT, 'wp_navigation');
    if ( ! $nav_post ) {
      $nav_post_id = wp_insert_post([
        'post_type' => 'wp_navigation',
        'post_title' => 'Primary Navigation',
        'post_status' => 'publish',
      ]);
    } else { $nav_post_id = $nav_post->ID; }

    // Build block content for navigation using core/navigation block that references menu items automatically is complex;
    // Instead store a simple navigation block that uses "overlayMenu":"always" + fallback to classic menu "Primary" by name.
    $content = '<!-- wp:navigation {"ref":0,"overlayMenu":"always","layout":{"type":"flex","justifyContent":"right"}} /-->';
    wp_update_post(['ID'=>$nav_post_id, 'post_content'=>$content]);

    // Bind header template-part to use this navigation entity
    $header = $this->get_or_create_template_part('header', 'Header');
    if ( $header ) {
      $header_content = '<!-- wp:group {"style":{"spacing":{"padding":{"top":"14px","bottom":"14px","left":"8px","right":"8px"}}},"backgroundColor":"primary","textColor":"background"} -->
<div class="wp-block-group has-background-color has-primary-background-color has-text-color has-background" style="padding-top:14px;padding-bottom:14px;padding-left:8px;padding-right:8px">
  <!-- wp:columns {"verticalAlignment":"center"} -->
  <div class="wp-block-columns are-vertically-aligned-center">
    <!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
      <!-- wp:site-title {"level":3} /-->
    </div>
    <!-- /wp:column -->
    <!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
    <div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
      <!-- wp:navigation {"overlayMenu":"always","layout":{"type":"flex","justifyContent":"right"}} /-->
    </div>
    <!-- /wp:column -->
  </div>
  <!-- /wp:columns -->
</div>
<!-- /wp:group -->';
      wp_update_post(['ID'=>$header->ID, 'post_content'=>$header_content]);
    }

    // Assign menu to location for classic themes (no-op for block themes but ok)
    $locations = get_theme_mod('nav_menu_locations');
    if ( ! is_array($locations) ) $locations = [];
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);

    return ['menu_id'=>$menu_id, 'nav_id'=>$nav_post_id, 'header_id'=>$header ? $header->ID : 0];
  }

  private function get_or_create_template_part( $slug, $title ) {
    $existing = get_page_by_path( $slug, OBJECT, 'wp_template_part' );
    if ( $existing ) return $existing;
    $id = wp_insert_post([
      'post_type' => 'wp_template_part',
      'post_name' => $slug,
      'post_title' => $title,
      'post_status' => 'publish',
      'tax_input' => ['wp_theme' => [ get_stylesheet() ]],
      'meta_input' => ['_wp_template_type' => 'template-part','_wp_template_part_area' => 'header']
    ]);
    return get_post( $id );
  }

  private function set_permalinks() {
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');
    $wp_rewrite->set_category_base('/category');
    $wp_rewrite->flush_rules();
    return get_option('permalink_structure');
  }

  private function purge_everything() {
    // Core level
    if ( function_exists('wp_cache_flush') ) wp_cache_flush();
    // Try LiteSpeed purge hooks (even if deactivated)
    do_action('litespeed_purge_all');
  }

  public function run() {
    $results = [];
    $results['mu_created'] = $this->create_mu_nocache();
    $results['litespeed_deactivated'] = $this->deactivate_litespeed();
    $results['theme'] = $this->ensure_theme();
    $pages = $this->rebuild_pages();
    $results['pages'] = $pages;
    $results['nav'] = $this->setup_menus_and_navigation( $pages );
    $results['permalinks'] = $this->set_permalinks();
    $this->purge_everything();
    return $results;
  }

  public function page() {
    if ( ! current_user_can('manage_options') ) return;
    echo '<div class="wrap"><h1>Farset HardFix (v1.0)</h1>';
    if ( isset($_POST['run_hardfix']) && check_admin_referer('farset_hardfix_nonce') ) {
      $r = $this->run();
      echo '<div class="notice notice-success"><p>Repair executed. MU no-cache enabled, LiteSpeed disabled, theme ensured, pages + nav rebuilt, permalinks set, caches purged.</p></div>';
      echo '<pre>' . esc_html( print_r($r, true) ) . '</pre>';
      echo '<p><strong>Next:</strong> Open the site in a private window. When satisfied, remove the MU no‑cache using the button below and re-activate LiteSpeed only if needed.</p>';
    }
    if ( isset($_POST['remove_mu']) && check_admin_referer('farset_hardfix_nonce') ) {
      $ok = $this->remove_mu_nocache();
      echo $ok ? '<div class="notice notice-success"><p>MU no‑cache file removed.</p></div>' : '<div class="notice notice-error"><p>Could not remove MU file; remove manually from wp-content/mu-plugins/' . self::MU_FILE . '</p></div>';
    }
    echo '<form method="post">';
    wp_nonce_field('farset_hardfix_nonce');
    submit_button('Run Full Repair Now', 'primary', 'run_hardfix');
    echo '</form>';
    echo '<hr/>';
    echo '<form method="post">';
    wp_nonce_field('farset_hardfix_nonce');
    submit_button('Remove MU No-Cache (when finished)', 'secondary', 'remove_mu');
    echo '</form>';
    echo '</div>';
  }
}
new FarsetTalent_HardFix();
