
(function($){
  $(document).on('click', '.farset-apply-btn', function(e){
    e.preventDefault();
    var job = $(this).data('job') || '';
    var $modal = $('#farset-apply-modal');
    var $overlay = $('#farset-apply-overlay');
    // Try to populate hidden field with class 'farset-job-field'
    setTimeout(function(){
      var $input = $modal.find('input.farset-job-field, input[name*="job"], input[name*="Job"]');
      if ($input.length) { $input.val(job).trigger('change'); }
    }, 100);
    $modal.addClass('open');
    $overlay.addClass('open');
    $('body').addClass('farset-modal-open');
  });
  function closeModal(){
    $('#farset-apply-modal').removeClass('open');
    $('#farset-apply-overlay').removeClass('open');
    $('body').removeClass('farset-modal-open');
  }
  $(document).on('click', '#farset-apply-close, #farset-apply-overlay', function(){ closeModal(); });
  $(document).on('keyup', function(e){ if(e.key === 'Escape'){ closeModal(); } });
})(jQuery);
