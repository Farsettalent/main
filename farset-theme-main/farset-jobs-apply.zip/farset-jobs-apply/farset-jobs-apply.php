
<?php
/**
 * Plugin Name: Farset Jobs & Apply Modal
 * Description: Renders a 4-job listing with "Apply Now" buttons that open a modal containing a WPForms form. Includes a settings page to edit jobs and set the WPForms form ID. Non-destructive and theme-agnostic.
 * Version: 1.0.0
 * Author: Farset Talent
 */

if (!defined('ABSPATH')) { exit; }

class Farset_Jobs_Apply {
    const OPTION_KEY = 'farset_jobs_apply_options';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('farset_jobs', [$this, 'shortcode_jobs']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_footer', [$this, 'render_modal']);
    }

    public static function defaults() {
        return [
            'form_id' => '',
            'jobs' => [
                ['title'=>'Warehouse Operative','location'=>'Belfast','type'=>'Full-time','summary'=>'Pick/pack, loading, health & safety. £11.44–£12.50/hr.','slug'=>'warehouse-operative'],
                ['title'=>'Class 2 LGV Driver','location'=>'Lisburn','type'=>'Contract','summary'=>'Multi-drop deliveries, CPC & Digi required. £14–£17/hr.','slug'=>'class-2-lgv-driver'],
                ['title'=>'Production Operative','location'=>'Derry/Londonderry','type'=>'Shift','summary'=>'Assembly line, QA checks. £11–£13/hr.','slug'=>'production-operative'],
                ['title'=>'Customer Support Advisor','location'=>'Belfast','type'=>'Permanent','summary'=>'Inbound queries, CRM updates, rota shifts. £22–25k + benefits.','slug'=>'customer-support-advisor'],
            ],
        ];
    }

    public function get_options() {
        $opts = get_option(self::OPTION_KEY, []);
        $defaults = self::defaults();
        if (empty($opts)) return $defaults;
        // merge
        $opts['jobs'] = isset($opts['jobs']) && is_array($opts['jobs']) ? $opts['jobs'] : $defaults['jobs'];
        $opts['form_id'] = isset($opts['form_id']) ? $opts['form_id'] : $defaults['form_id'];
        return $opts;
    }

    public function admin_menu() {
        add_menu_page('Farset Jobs', 'Farset Jobs', 'manage_options', 'farset-jobs', [$this, 'settings_page'], 'dashicons-id-alt', 25);
    }

    public function register_settings() {
        register_setting('farset_jobs_group', self::OPTION_KEY);
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $opts = $this->get_options();
        ?>
        <div class="wrap">
          <h1>Farset Jobs & Apply Modal</h1>
          <form method="post" action="options.php">
            <?php settings_fields('farset_jobs_group'); ?>
            <?php $val = get_option(self::OPTION_KEY, self::defaults()); ?>
            <h2>WPForms Integration</h2>
            <p>Create or import an "Apply Now" WPForms form and enter its <strong>Form ID</strong> here. Add a <strong>Hidden Field</strong> with CSS class <code>farset-job-field</code> so it is populated with the clicked job title.</p>
            <table class="form-table">
              <tr>
                <th scope="row"><label for="form_id">WPForms Form ID</label></th>
                <td><input name="<?php echo self::OPTION_KEY; ?>[form_id]" id="form_id" type="text" value="<?php echo esc_attr($opts['form_id']); ?>" class="regular-text" /></td>
              </tr>
            </table>
            <h2>Jobs (max 4)</h2>
            <table class="widefat striped">
              <thead><tr><th>#</th><th>Title</th><th>Location</th><th>Type</th><th>Summary</th><th>Slug</th></tr></thead>
              <tbody>
              <?php for ($i=0; $i<4; $i++):
                $j = isset($opts['jobs'][$i]) ? $opts['jobs'][$i] : ['title'=>'','location'=>'','type'=>'','summary'=>'','slug'=>''];
              ?>
              <tr>
                <td><?php echo $i+1; ?></td>
                <td><input name="<?php echo self::OPTION_KEY; ?>[jobs][<?php echo $i; ?>][title]" type="text" value="<?php echo esc_attr($j['title']); ?>" class="regular-text" /></td>
                <td><input name="<?php echo self::OPTION_KEY; ?>[jobs][<?php echo $i; ?>][location]" type="text" value="<?php echo esc_attr($j['location']); ?>" class="regular-text" /></td>
                <td><input name="<?php echo self::OPTION_KEY; ?>[jobs][<?php echo $i; ?>][type]" type="text" value="<?php echo esc_attr($j['type']); ?>" class="regular-text" /></td>
                <td><input name="<?php echo self::OPTION_KEY; ?>[jobs][<?php echo $i; ?>][summary]" type="text" value="<?php echo esc_attr($j['summary']); ?>" class="regular-text" /></td>
                <td><input name="<?php echo self::OPTION_KEY; ?>[jobs][<?php echo $i; ?>][slug]" type="text" value="<?php echo esc_attr($j['slug']); ?>" class="regular-text" /></td>
              </tr>
              <?php endfor; ?>
              </tbody>
            </table>
            <?php submit_button(); ?>
          </form>
          <h2>How to use</h2>
          <ol>
            <li>Import the supplied WPForms JSON (Apply Now) or build your own. Ensure there is a Hidden Field with CSS class <code>farset-job-field</code>.</li>
            <li>Place the shortcode <code>[farset_jobs]</code> on the <strong>Jobs</strong> page.</li>
            <li>Set your form ID above. Clicking <em>Apply now</em> opens a modal and populates the job field.</li>
          </ol>
        </div>
        <?php
    }

    public function enqueue_assets() {
        $css = "
        .farset-jobs-list{display:flex;flex-direction:column;gap:14px}
        .farset-job-card{background:#fff;border:1px solid rgba(10,26,43,.12);border-radius:14px;padding:14px 16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
        .farset-job-top{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap}
        .farset-job-title{font-weight:700}
        .farset-muted{opacity:.8}
        .farset-apply-btn{background:#d4a017;color:#fff;border:0;border-radius:10px;padding:10px 14px;cursor:pointer}
        .farset-apply-btn:hover{background:#845f00}
        /* Modal */
        .farset-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);display:none;z-index:9998}
        .farset-modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:9999}
        .farset-modal.open,.farset-modal-overlay.open{display:flex}
        .farset-modal .farset-box{max-width:720px;width:92%;background:#fff;border-radius:16px;padding:20px;box-shadow:0 10px 40px rgba(0,0,0,.2)}
        .farset-modal .farset-close{position:absolute;top:16px;right:20px;font-size:22px;cursor:pointer}
        ";
        wp_add_inline_style('wp-block-library', $css);
        wp_register_script('farset-jobs-apply', plugins_url('jobs-apply.js', __FILE__), ['jquery'], '1.0.0', true);
        $opts = $this->get_options();
        wp_localize_script('farset-jobs-apply', 'FarsetJobsApply', [
            'formId' => $opts['form_id'],
        ]);
        wp_enqueue_script('farset-jobs-apply');
    }

    public function shortcode_jobs($atts) {
        $opts = $this->get_options();
        $jobs = array_slice($opts['jobs'], 0, 4);
        ob_start(); ?>
        <div class="farset-jobs-list">
        <?php foreach ($jobs as $job): if (empty($job['title'])) continue; ?>
          <div class="farset-job-card">
            <div class="farset-job-top">
              <div class="farset-job-title"><?php echo esc_html($job['title']); ?></div>
              <div class="farset-muted"><?php echo esc_html($job['location']); ?> · <?php echo esc_html($job['type']); ?></div>
            </div>
            <div class="farset-job-summary"><?php echo esc_html($job['summary']); ?></div>
            <div style="margin-top:10px;display:flex;gap:10px;align-items:center">
              <a class="farset-muted" href="<?php echo esc_url( home_url( '/jobs/' . sanitize_title($job['slug']) . '/' ) ); ?>">View role →</a>
              <button class="farset-apply-btn" data-job="<?php echo esc_attr($job['title']); ?>">Apply now</button>
            </div>
          </div>
        <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_modal() {
        // Always render modal container; content will be the WPForms form if form_id set.
        $opts = $this->get_options();
        ?>
        <div class="farset-modal-overlay" id="farset-apply-overlay"></div>
        <div class="farset-modal" id="farset-apply-modal">
          <div class="farset-box">
            <div class="farset-close" id="farset-apply-close" aria-label="Close">✕</div>
            <?php
            if (!empty($opts['form_id'])) {
                echo do_shortcode('[wpforms id="' . intval($opts['form_id']) . '" title="false" description="false"]');
            } else {
                echo '<p><strong>Apply form not set.</strong> Go to <em>Farset Jobs</em> settings and enter your WPForms Form ID.</p>';
            }
            ?>
          </div>
        </div>
        <?php
    }
}

new Farset_Jobs_Apply();
