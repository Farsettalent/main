<?php
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style( 'farsettalent-parent', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'farsettalent-child', get_stylesheet_uri(), ['farsettalent-parent'], '1.1.0' );
});
?>