<?php
/*
Plugin Name: Farset Talent LinkFix
Description: Sets up pages, menus, and assigns templates for Farset Talent site.
Version: 1.0
Author: Farset Talent
*/
register_activation_hook(__FILE__, function() {
    $pages = ['Home','Jobs','Submit CV','Clients','About','Contact','Privacy Policy','Terms of Business'];
    foreach ($pages as $title) {
        if (!get_page_by_title($title)) {
            wp_insert_post([ 'post_title'=>$title,'post_status'=>'publish','post_type'=>'page' ]);
        }
    }
    $home = get_page_by_title('Home');
    if ($home) {
        update_option('page_on_front', $home->ID);
        update_option('show_on_front', 'page');
    }
    $menu_name = 'Primary';
    $menu_id = wp_create_nav_menu($menu_name);
    foreach ($pages as $title) {
        $page = get_page_by_title($title);
        if ($page) {
            wp_update_nav_menu_item($menu_id, 0, [ 'menu-item-title'=>$title,'menu-item-object-id'=>$page->ID,'menu-item-object'=>'page','menu-item-type'=>'post_type','menu-item-status'=>'publish' ]);
        }
    }
    $locations = get_theme_mod('nav_menu_locations');
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations',$locations);
});
?>